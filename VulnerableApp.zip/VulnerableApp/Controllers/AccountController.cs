﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace VulnerableApp.Controllers
{
    public class AccountController : Controller
    {
        private readonly string connectionString = "Data Source=LAPTOP-4KNUMMCK\\SQLEXPRESS;Initial Catalog=VulnerableDB;Integrated Security=True;TrustServerCertificate=True;";

        [HttpGet]
        public IActionResult Login() => View();

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            bool isAuthenticated = false;

           
            // ✅ Güvenli hali (parametreli sorgu):
            using (SqlConnection conn = new SqlConnection(connectionString))
{
    conn.Open();

    string query = "SELECT * FROM Users WHERE Username = @username AND Password = @password";
    SqlCommand cmd = new SqlCommand(query, conn);
    cmd.Parameters.AddWithValue("@username", username);
    cmd.Parameters.AddWithValue("@password", password);
    SqlDataReader reader = cmd.ExecuteReader();

    if (reader.HasRows)
    {
        isAuthenticated = true;
    }
}

            if (isAuthenticated)
            {
                HttpContext.Session.SetString("username", username);
                return RedirectToAction("Profile");
            }

            ViewData["Error"] = "Geçersiz kullanıcı adı ya da şifre.";
            return View();
        }

        public IActionResult Profile()
        {
            // ⚠️ Broken Access Control — login kontrolü yok
            
            return View();
        }

        /*
        // ✅ Güvenli Access Control:
        if (HttpContext.Session.GetString("username") == null)
        {
            return RedirectToAction("Login");
        }
        */

        [HttpPost]
        public IActionResult Profile(string bio)
        {
            // ⚠️ Reflected XSS
            ViewData["Bio"] = bio;
            return View();
        }

        /*
        // ✅ Güvenli Reflected XSS:
        ViewData["Bio"] = System.Net.WebUtility.HtmlEncode(bio);
        */
    }
}
